package br.com.fiap.CompliCheck.API.entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "T_NORMA")

public class Norma {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_norma;

    @ManyToOne
    @JoinColumn(name="id_checklist", nullable = false)
    private Checklist id_checklist;

    @Column (nullable = false)
    private String titulo;

    @Column(nullable = false)
    private String ementa;

    @Column(nullable = false)
    private Date dt_aprovacao;

    @Column(nullable = false)
    private String orgao;

    @Column(nullable = false)
    private String link;

    public long getId_norma() {
        return id_norma;
    }

    public void setId_norma(long id_norma) {
        this.id_norma = id_norma;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Date getDt_aprovacao() {
        return dt_aprovacao;
    }

    public void setDt_aprovacao(Date dt_aprovacao) {
        this.dt_aprovacao = dt_aprovacao;
    }

    public String getEmenta() {
        return ementa;
    }

    public void setEmenta(String ementa) {
        this.ementa = ementa;
    }

    public String getOrgao() {
        return orgao;
    }

    public void setOrgao(String orgao) {
        this.orgao = orgao;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
