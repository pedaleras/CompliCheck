package br.com.fiap.CompliCheck.API.entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "T_EMPRESA")

public class Empresa {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_empresa;

    @ManyToOne
    @JoinColumn(name="id_usuario", nullable = false)
    private Usuario id_usuario;

    @Column(nullable = false, unique = true)
    private String nome_empresa;

    @Column(nullable = false, unique = true)
    private String cnpj;

    @Column(nullable = false)
    private String segmento;

    @Column(nullable = false)
    private Date dt_inicio;

    @Column (nullable = false)
    private Date dt_final;

    public Enum getNv_acesso() {
        return nv_acesso;
    }

    public void setNv_acesso(Enum nv_acesso) {
        this.nv_acesso = nv_acesso;
    }

    public Date getDt_final() {
        return dt_final;
    }

    public void setDt_final(Date dt_final) {
        this.dt_final = dt_final;
    }

    public Date getDt_inicio() {
        return dt_inicio;
    }

    public void setDt_inicio(Date dt_inicio) {
        this.dt_inicio = dt_inicio;
    }

    public String getSegmento() {
        return segmento;
    }

    public void setSegmento(String segmento) {
        this.segmento = segmento;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getNome_empresa() {
        return nome_empresa;
    }

    public void setNome_empresa(String nome_empresa) {
        this.nome_empresa = nome_empresa;
    }

    public long getId_empresa() {
        return id_empresa;
    }

    public void setId_empresa(long id_empresa) {
        this.id_empresa = id_empresa;
    }

    @Column (nullable = false)
    private Enum nv_acesso;
}
