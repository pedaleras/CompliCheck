package br.com.fiap.CompliCheck.API.entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "T_CHECKLIST")

public class Checklist {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id_checklist;

    @ManyToOne
    @JoinColumn(name="id_empresa", nullable = false)
    private Empresa id_empresa;

    @ManyToOne
    @JoinColumn(name="id_norma", nullable = false)
    private Norma id_norma;

    @Column(nullable = false)
    private Date dt_checklist;

    @Column(nullable = false)
    private String qt_irregularidades;

    @Column(nullable = false)
    private String qt_regularidades;

    @Column(nullable = false)
    private String ds_solucao;

    public long getId_checklist() {
        return id_checklist;
    }

    public void setId_checklist(long id_checklist) {
        this.id_checklist = id_checklist;
    }

    public String getDs_solucao() {
        return ds_solucao;
    }

    public void setDs_solucao(String ds_solucao) {
        this.ds_solucao = ds_solucao;
    }

    public Date getDt_checklist() {
        return dt_checklist;
    }

    public void setDt_checklist(Date dt_checklist) {
        this.dt_checklist = dt_checklist;
    }

    public String getQt_irregularidades() {
        return qt_irregularidades;
    }

    public void setQt_irregularidades(String qt_irregularidades) {
        this.qt_irregularidades = qt_irregularidades;
    }

    public String getQt_regularidades() {
        return qt_regularidades;
    }

    public void setQt_regularidades(String qt_regularidades) {
        this.qt_regularidades = qt_regularidades;
    }

    public Empresa getId_empresa() {
        return id_empresa;
    }

    public void setId_empresa(Empresa id_empresa) {
        this.id_empresa = id_empresa;
    }
}
