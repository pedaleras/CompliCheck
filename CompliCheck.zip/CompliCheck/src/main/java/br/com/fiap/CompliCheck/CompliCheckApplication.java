package br.com.fiap.CompliCheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompliCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompliCheckApplication.class, args);
	}

}
