package br.com.fiap.CompliCheck.API.entity;


import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "T_ALERTA")

public class Alerta {

    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private long id_alerta;

    @ManyToOne
    @JoinColumn(name="id_norma", nullable = false)
    private Norma id_norma;

    @ManyToOne
    @JoinColumn(name="id_usuario", nullable = false)
    private Usuario id_usuario;

    @Column(nullable = false)
    private String nm_alerta;

    @Column(nullable = false)
    private Date dt_alerta;

    @Column(nullable = false)
    private String ds_alerta;



}
