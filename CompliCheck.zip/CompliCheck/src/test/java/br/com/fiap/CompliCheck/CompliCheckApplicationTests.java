package br.com.fiap.CompliCheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompliCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
